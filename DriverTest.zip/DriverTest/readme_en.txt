This is just English translation of End User Agreement of
mocapdata.com in Japanese.
Please refer and agree with this license in Japanese.

LICENSE FOR MOCAPDATA PURCHASED FROM MOCAPDATA.COM CREATOR'S RIGHTS

-The creator retains all copyrights to the enclosed motion capture data.
-The Buyer is only purchasing the right to use the contents, not ownership of the actual files.
-The Buyer may not redistribute this archive file, in whole or in part.
-The Buyer may not store it any place on a network or on the Internet 
 where it may be acquired by a third party (this includes making it  
 available on your hard-drive for direct download using Peer to Peer  Software).

BUYER'S RIGHTS
-The Buyer is hereby granted a non-exclusive, non-transferable license 
 to use all of the contents of the encapsulating archive file for 
 artistic renders or as reference.
-Artist maintains that all items in the archive are their original
 work, or are derivative works from something found, and verified, to 
 be in the public domain or purchased with permission of commercial use.
-Artist maintains they legally possess the power to grant the Buyer 
 this license for all enclosed materials.
-Buyer may use the materials in any personal projects or commercial 
 projects, as long as the Artist 's work is protected from extraction 
 and none of the items above have been violated.
-Buyer may make backup copies of this archive file, for personal
 archival purposes only. 
-Buyer retains this license, even if the Artist stops selling this 
 work at a later date, or decides to charge a different price.
-The Artist may only revoke this license, if it is shown that a Buyer has 
 previously violated the terms and conditions above.

All Sales are Final and not refundable.
Contact:
Eyes, JAPAN Co. Ltd.9-15 Higashisakae Aizuwakamatsu
Fukushima 965-0872 JAPAN
Tel: +81242-38-2023
URL: http://mocapdata.com
E-mail: info@mocapdata.com
